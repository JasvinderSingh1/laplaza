<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-10-23 10:52:23 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\laplaza_live\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2017-10-23 10:52:23 --> Unable to connect to the database
ERROR - 2017-10-23 10:53:02 --> 404 Page Not Found: Assets/front
ERROR - 2017-10-23 10:53:03 --> 404 Page Not Found: Assets/front
ERROR - 2017-10-23 10:53:07 --> 404 Page Not Found: Assets/front
