<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-10-12 11:22:48 --> 404 Page Not Found: Assets/front
ERROR - 2017-10-12 11:22:52 --> Severity: Notice --> Undefined property: mysqli::$r_name /home/enablersws/public_html/ewsdev.in/tutor/application/views/bookings_html.php 48
ERROR - 2017-10-12 11:22:52 --> Severity: Notice --> Undefined property: mysqli::$price /home/enablersws/public_html/ewsdev.in/tutor/application/views/bookings_html.php 49
ERROR - 2017-10-12 11:22:52 --> Severity: Notice --> Undefined property: mysqli::$id /home/enablersws/public_html/ewsdev.in/tutor/application/views/bookings_html.php 66
ERROR - 2017-10-12 11:22:52 --> Severity: Notice --> Undefined property: mysqli_result::$r_name /home/enablersws/public_html/ewsdev.in/tutor/application/views/bookings_html.php 48
ERROR - 2017-10-12 11:22:52 --> Severity: Notice --> Undefined property: mysqli_result::$price /home/enablersws/public_html/ewsdev.in/tutor/application/views/bookings_html.php 49
ERROR - 2017-10-12 11:22:52 --> Severity: Notice --> Undefined property: mysqli_result::$id /home/enablersws/public_html/ewsdev.in/tutor/application/views/bookings_html.php 66
ERROR - 2017-10-12 11:22:52 --> Severity: Notice --> Trying to get property of non-object /home/enablersws/public_html/ewsdev.in/tutor/application/views/bookings_html.php 48
ERROR - 2017-10-12 11:22:52 --> Severity: Notice --> Trying to get property of non-object /home/enablersws/public_html/ewsdev.in/tutor/application/views/bookings_html.php 49
ERROR - 2017-10-12 11:22:52 --> Severity: Notice --> Trying to get property of non-object /home/enablersws/public_html/ewsdev.in/tutor/application/views/bookings_html.php 66
ERROR - 2017-10-12 11:22:52 --> Severity: Notice --> Trying to get property of non-object /home/enablersws/public_html/ewsdev.in/tutor/application/views/bookings_html.php 48
ERROR - 2017-10-12 11:22:52 --> Severity: Notice --> Trying to get property of non-object /home/enablersws/public_html/ewsdev.in/tutor/application/views/bookings_html.php 49
ERROR - 2017-10-12 11:22:52 --> Severity: Notice --> Trying to get property of non-object /home/enablersws/public_html/ewsdev.in/tutor/application/views/bookings_html.php 66
ERROR - 2017-10-12 11:22:52 --> Severity: Notice --> Trying to get property of non-object /home/enablersws/public_html/ewsdev.in/tutor/application/views/bookings_html.php 48
ERROR - 2017-10-12 11:22:52 --> Severity: Notice --> Trying to get property of non-object /home/enablersws/public_html/ewsdev.in/tutor/application/views/bookings_html.php 49
ERROR - 2017-10-12 11:22:52 --> Severity: Notice --> Trying to get property of non-object /home/enablersws/public_html/ewsdev.in/tutor/application/views/bookings_html.php 66
ERROR - 2017-10-12 11:22:52 --> Severity: Notice --> Trying to get property of non-object /home/enablersws/public_html/ewsdev.in/tutor/application/views/bookings_html.php 48
ERROR - 2017-10-12 11:22:52 --> Severity: Notice --> Trying to get property of non-object /home/enablersws/public_html/ewsdev.in/tutor/application/views/bookings_html.php 49
ERROR - 2017-10-12 11:22:52 --> Severity: Notice --> Trying to get property of non-object /home/enablersws/public_html/ewsdev.in/tutor/application/views/bookings_html.php 66
ERROR - 2017-10-12 11:22:52 --> Severity: Notice --> Trying to get property of non-object /home/enablersws/public_html/ewsdev.in/tutor/application/views/bookings_html.php 48
ERROR - 2017-10-12 11:22:52 --> Severity: Notice --> Trying to get property of non-object /home/enablersws/public_html/ewsdev.in/tutor/application/views/bookings_html.php 49
ERROR - 2017-10-12 11:22:52 --> Severity: Notice --> Trying to get property of non-object /home/enablersws/public_html/ewsdev.in/tutor/application/views/bookings_html.php 66
ERROR - 2017-10-12 11:22:52 --> Severity: Notice --> Trying to get property of non-object /home/enablersws/public_html/ewsdev.in/tutor/application/views/bookings_html.php 48
ERROR - 2017-10-12 11:22:52 --> Severity: Notice --> Trying to get property of non-object /home/enablersws/public_html/ewsdev.in/tutor/application/views/bookings_html.php 49
ERROR - 2017-10-12 11:22:52 --> Severity: Notice --> Trying to get property of non-object /home/enablersws/public_html/ewsdev.in/tutor/application/views/bookings_html.php 66
ERROR - 2017-10-12 11:22:52 --> 404 Page Not Found: Assets/front
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ERROR - 2017-10-12 11:35:37 --> Severity: Compile Error --> Can't use method return value in write context /home/enablersws/public_html/ewsdev.in/tutor/application/views/bookings_html.php 38
ERROR - 2017-10-12 11:36:10 --> 404 Page Not Found: Assets/front
ERROR - 2017-10-12 11:36:19 --> 404 Page Not Found: Assets/front
ERROR - 2017-10-12 11:36:23 --> 404 Page Not Found: Assets/front
ERROR - 2017-10-12 11:36:31 --> 404 Page Not Found: Assets/front
ERROR - 2017-10-12 11:36:31 --> 404 Page Not Found: Assets/front
ERROR - 2017-10-12 11:38:44 --> 404 Page Not Found: Assets/front
ERROR - 2017-10-12 11:38:45 --> 404 Page Not Found: Assets/front
ERROR - 2017-10-12 11:38:49 --> 404 Page Not Found: Assets/front
ERROR - 2017-10-12 11:40:02 --> 404 Page Not Found: Assets/front
ERROR - 2017-10-12 11:40:06 --> 404 Page Not Found: Assets/front
ERROR - 2017-10-12 11:52:13 --> 404 Page Not Found: Assets/front
ERROR - 2017-10-12 11:52:17 --> 404 Page Not Found: Assets/front
ERROR - 2017-10-12 11:52:59 --> 404 Page Not Found: Assets/front
ERROR - 2017-10-12 11:53:04 --> 404 Page Not Found: Assets/front
ERROR - 2017-10-12 21:53:55 --> 404 Page Not Found: Robotstxt/index
