<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-10-14 05:16:59 --> 404 Page Not Found: Img/favicon.ico
ERROR - 2017-10-14 05:19:20 --> 404 Page Not Found: Admin_login/img
ERROR - 2017-10-14 05:19:23 --> 404 Page Not Found: Assets/front
ERROR - 2017-10-14 05:19:25 --> 404 Page Not Found: Assets/front
ERROR - 2017-10-14 05:19:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2017-10-14 06:02:15 --> 404 Page Not Found: Assets/front
ERROR - 2017-10-14 09:14:13 --> 404 Page Not Found: Img/favicon.ico
ERROR - 2017-10-14 09:14:27 --> 404 Page Not Found: Admin_login/img
ERROR - 2017-10-14 09:14:31 --> 404 Page Not Found: Assets/front
ERROR - 2017-10-14 09:14:33 --> 404 Page Not Found: Assets/front
ERROR - 2017-10-14 09:14:45 --> 404 Page Not Found: Assets/front
ERROR - 2017-10-14 09:15:08 --> 404 Page Not Found: Assets/front
ERROR - 2017-10-14 09:15:09 --> 404 Page Not Found: Assets/front
ERROR - 2017-10-14 09:17:29 --> 404 Page Not Found: Assets/front
ERROR - 2017-10-14 09:17:29 --> 404 Page Not Found: Assets/front
ERROR - 2017-10-14 09:17:48 --> 404 Page Not Found: Assets/front
ERROR - 2017-10-14 09:17:49 --> 404 Page Not Found: Assets/front
ERROR - 2017-10-14 09:17:51 --> 404 Page Not Found: Assets/front
ERROR - 2017-10-14 09:17:51 --> 404 Page Not Found: Assets/front
ERROR - 2017-10-14 09:18:02 --> 404 Page Not Found: Assets/front
ERROR - 2017-10-14 09:20:12 --> Severity: Warning --> mail(): Failed to connect to mailserver at &quot;localhost&quot; port 25, verify your &quot;SMTP&quot; and &quot;smtp_port&quot; setting in php.ini or use ini_set() C:\xampp\htdocs\survey\system\libraries\Email.php 1888
ERROR - 2017-10-14 09:20:12 --> 404 Page Not Found: Assets/front
ERROR - 2017-10-14 09:20:37 --> 404 Page Not Found: Assets/front
ERROR - 2017-10-14 09:20:40 --> 404 Page Not Found: Assets/front
ERROR - 2017-10-14 09:20:43 --> 404 Page Not Found: Assets/front
ERROR - 2017-10-14 09:20:48 --> 404 Page Not Found: Assets/front
ERROR - 2017-10-14 09:20:55 --> 404 Page Not Found: Assets/front
ERROR - 2017-10-14 09:21:52 --> 404 Page Not Found: Assets/front
ERROR - 2017-10-14 09:22:57 --> 404 Page Not Found: Assets/front
ERROR - 2017-10-14 09:22:58 --> 404 Page Not Found: Assets/front
ERROR - 2017-10-14 09:24:31 --> 404 Page Not Found: Assets/front
ERROR - 2017-10-14 09:24:32 --> 404 Page Not Found: Assets/front
