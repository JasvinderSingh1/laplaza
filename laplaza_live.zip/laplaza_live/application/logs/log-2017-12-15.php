<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-12-15 06:49:42 --> 404 Page Not Found: Assets/front
ERROR - 2017-12-15 06:49:43 --> 404 Page Not Found: Assets/front
ERROR - 2017-12-15 06:49:53 --> 404 Page Not Found: Img/favicon.ico
ERROR - 2017-12-15 06:50:00 --> 404 Page Not Found: Admin_login/img
ERROR - 2017-12-15 06:50:52 --> 404 Page Not Found: Img/favicon.ico
