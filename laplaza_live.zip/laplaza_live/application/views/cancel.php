
<?php include('header_front.php');?>
	<div id="demo-1" class="banner-inner">
		<!--/header-w3l-->
			   <div class="header-w3-agileits" id="home">
			    <?php include('head_front_html.php');?>
		<!--//header-w3l-->
	
		</div>
	</div>
		 <div class="w3_content_agilleinfo_inner">
					    <div class="container">
							<div class="inner-agile-w3l-part-head">
					           <h2 class="w3l-inner-h-title">Booking Cancelled</h2>
								
							</div>
									<div class="w3_mail_grids">
										<div>
	<h3 style="font-family: 'quicksandbold'; font-size:16px; color:#313131; padding-bottom:8px;">Dear Guest</h3>
    <span style="color:#D70000; font-size:16px; font-weight:bold;">We are sorry! Your last transaction was cancelled.</span>
</div>

							</div>
							<div class="agileinf-button">    <a class="read" href="/bookings">
											Try again
							   </a>
							   </div>
					   </div>
				  </div>

	 <?php include('footer_front.php');?>