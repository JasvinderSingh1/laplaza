<?php
									foreach ($allrooms as $room)
									{
										echo $room->room_no;
										}
					 
					   ?>